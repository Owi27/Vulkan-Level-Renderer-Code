var class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d =
[
    [ "GCollisionCheck2D", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a4be51ac1efb660fed9bc95edafcfe282", [
      [ "ERROR_NO_RESULT", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a4be51ac1efb660fed9bc95edafcfe282a1f7c402ecf04b66580b84611b64cc019", null ],
      [ "ABOVE", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a4be51ac1efb660fed9bc95edafcfe282ac2d92b81beeac9bfc89fb870c1a20767", null ],
      [ "BELOW", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a4be51ac1efb660fed9bc95edafcfe282aa25949e21299b84cc33c4b00c740f08f", null ],
      [ "NO_COLLISION", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a4be51ac1efb660fed9bc95edafcfe282a874a40b8eb0a1602fae9e93767a85f08", null ],
      [ "COLLISION", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a4be51ac1efb660fed9bc95edafcfe282afc3ca10632f0c7aa3aaea07a234377db", null ]
    ] ],
    [ "Create", "class_g_w_1_1_m_a_t_h2_d_1_1_g_collision2_d.html#a264a870f35828458104db28e55a8446b", null ]
];