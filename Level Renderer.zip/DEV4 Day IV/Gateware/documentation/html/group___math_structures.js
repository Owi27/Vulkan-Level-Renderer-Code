var group___math_structures =
[
    [ "GVECTORF", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html", [
      [ "xy", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#a5ca6cea69904f148f7fb1d375a27b6f3", null ],
      [ "xyz", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#a6dcd524630125c907988571c56f9b00e", null ],
      [ "xyzw", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#a31570697d4854d64f795458984fa1aed", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#a1e58106098cee18ccca5a8ae2458086f", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#a1b069fc0c18416c93463bc5da8e52c44", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#aa323ff25f2fe2bc2a4dd7c7ce3c00394", null ],
      [ "w", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#ac0d112f2d6b83e49541ebbf259a97320", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_f.html#a19527bde37e35d30b7deb8568794c267", null ]
    ] ],
    [ "GVECTORD", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html", [
      [ "xy", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a985ed3e8e69052d51c9e83c0b617c228", null ],
      [ "xyz", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a77aee501e0b16824d8c05b4017e535f2", null ],
      [ "xyzw", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a6460de1ced24eee0a081996d2a643f8d", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a7d3566f39f8c3149595edec8958c225c", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a9929d4553067cc58a5477fdee56ac49b", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a831403a04b3b15ecc9b265eb531bb8e4", null ],
      [ "w", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a0820e1e99e3d83e4098616e9dd0fca7e", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_v_e_c_t_o_r_d.html#a3f61f48fb22b0382f6558bc1fa7d8a60", null ]
    ] ],
    [ "GMATRIXF", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html", [
      [ "row1", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html#ab581ff95666f0b2d98fcc3350c51dac6", null ],
      [ "row2", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html#ada9e242a835a74f209c7eb335eb5f4dd", null ],
      [ "row3", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html#a2f1e35528f1c59c9aa95a59b0652e9c5", null ],
      [ "row4", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html#ab1442f90ffbf58953cbb8bb2ca9aedaf", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_f.html#a062a182a6445f389fc5447ad1cf41faf", null ]
    ] ],
    [ "GMATRIXD", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html", [
      [ "row1", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html#a270fe0641cf9a788fcc9d10ec7b35747", null ],
      [ "row2", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html#a1bc368e1d72975a5225bd459f9c702e4", null ],
      [ "row3", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html#ad764bceafb36028a86a842360d92c48e", null ],
      [ "row4", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html#a56f3efe697bceb4e33833f95106e359b", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_m_a_t_r_i_x_d.html#a8751be0a0a7453662eda46a93889f0e4", null ]
    ] ],
    [ "GQUATERNIONF", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html", [
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html#aeafc0c7c427d178d46feb1809966b7ba", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html#a9ccf1c11c547b434fb92c99f3366700c", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html#a1b1e0bf8cef890cdff4cf78f634ba5e2", null ],
      [ "w", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html#a54b4529321f6a82f01406466a5fe1f2d", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_f.html#a13306af7f2f7c2036f4fe9f275eb6d93", null ]
    ] ],
    [ "GQUATERNIOND", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html", [
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html#a5780c909e288ae83c6af4c25fb61e568", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html#a2c06d425a33b3727161d287dfa9a6621", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html#abbafb17f1b95bf2268f1e3cda4009395", null ],
      [ "w", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html#aca1f0e5d5c2e3240b813b9588aa22a82", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_q_u_a_t_e_r_n_i_o_n_d.html#a80ffd8ebddc8cca59f90d0c9a11caf62", null ]
    ] ],
    [ "GLINEF", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html#ab3754d089b45b60362694a7ba72e7204", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html#ab8645e45718f7c39a0a02c6590c099f9", null ],
      [ "start", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html#ae8db252ab12b560108d8b5cc17e68eed", null ],
      [ "end", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html#ae163b98da09265bcfd8192da1da9efdf", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_f.html#a648f8df7bbf1df985e7222e12fe779aa", null ]
    ] ],
    [ "GLINED", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html#a3aee6bc9170c77143b32575afb657eb6", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html#a3dff71c534164d9d93103e225c8811ea", null ],
      [ "start", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html#a6b00c3fd539f744e765f61b6ca28353c", null ],
      [ "end", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html#a3917eb3a53a309d58283a93cb6d99fc0", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_l_i_n_e_d.html#a94bb3a8bbaaf99786bc37fab81d1ec24", null ]
    ] ],
    [ "GRAYF", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html#a4620a795cbb975bcfe9dde461235f011", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html#aeadf8a0e3b983db10abf285b7907b912", null ],
      [ "position", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html#a43fdf692615ad27c4ca39798d1126f9e", null ],
      [ "direction", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html#a73fc61264ebc4b53df35a5c315d02aed", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_f.html#a5dc164cd2bcce5b6c5cb51548d948b21", null ]
    ] ],
    [ "GRAYD", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html#a35c4b6453b463e7819768e52fb7fd927", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html#a2a97b6e759c3f8813e0fcb87ec7cd100", null ],
      [ "position", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html#a640e9333f7cdfb64efa87a397c29ae24", null ],
      [ "direction", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html#a080344603245e9b10e1715f93156b9f8", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_r_a_y_d.html#a2fdabf0fe48e4bc48cfb2c4015bc2886", null ]
    ] ],
    [ "GTRIANGLEF", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html#a315345a6b36f66d1e6f6f27baf66cfbf", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html#a4524b630969929128da48095710e241e", null ],
      [ "a", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html#ae56f54c67b2a8196b2306addf0edf7c0", null ],
      [ "b", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html#a6165be5f71879cb17c103447ef7111cb", null ],
      [ "c", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html#aba611219d64e63c49f7f64a457462100", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_f.html#a67a61cf7bef38936cf03d9b3ba03f069", null ]
    ] ],
    [ "GTRIANGLED", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html#a4ba45fd0cc6ade3bf3419b0ace874f1b", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html#a7f18eec22c5f0d3b7cfbe677051560aa", null ],
      [ "a", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html#a89a0357c08b43c94e36a364bb6823732", null ],
      [ "b", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html#ac657b327a18a6cfb62d4376e2cb52cb4", null ],
      [ "c", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html#a8392c8e8af4fbac4a7e38309f774b2a0", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_t_r_i_a_n_g_l_e_d.html#ae6081e200da4f2c4d83c4546fcad7451", null ]
    ] ],
    [ "GPLANEF", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#a4a99f5f0e85f88f0073b9337d42fde80", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#a02252af8dbfe59aa78d52eb386d526e9", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#a4dddb1ecefe60dfeb24d7a299ff7054a", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#aa0127800e9639bac443c1499c2a1b2aa", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#af5289fa1397972ce63aba6f93cfa9a9d", null ],
      [ "distance", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#a5689da5f34f29ffdcba9500c61716d84", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_f.html#ae3042e00971fdc087bd5a29bd0bd33d8", null ]
    ] ],
    [ "GPLANED", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#a66c9826aa19750298afaeb14b1f2b7f6", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#a19b232201af0b134a6071f647b548c3d", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#af7caedbd8bf7b0204404c7129ded8364", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#a0ae86d50088ab32fee87d805f13e959c", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#ae871a3945a02d2e2e45eeff68e4331d3", null ],
      [ "distance", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#a8868f7e061ce272ad0fc1dddb89ad2a9", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_p_l_a_n_e_d.html#a9cc9367d88f5d164efd7f652fb276c0d", null ]
    ] ],
    [ "GSPHEREF", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#add77361827a2e4d9ba10ae321c5dca4c", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#a728f6c0e787a48dbce7adc3fb9ce170c", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#aed936279847428b2c0a12335b59e5974", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#a53506c1eacd099cb5bb6d1bd05f99344", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#aa56e45ae522e72767b5283d902782512", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#a88ad9ceb3c6d185f928888708a0002de", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_f.html#ab1a8b14249705a3c0cc2404b05612551", null ]
    ] ],
    [ "GSPHERED", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#ae6ea3f73470d1dc30681ae830e5841bc", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#ad972c09d6964883555b8242db6aa7d26", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#a2e7c726583c92bef4e4bdba8ffa2328e", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#a893ea9e080528fb19789abf2cbd10cd7", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#a38bc25bc091f455f5bb55a16a898342b", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#a40f87fb9525326805957c2984a3cd785", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_s_p_h_e_r_e_d.html#acd14e4950863eedb97edb822e73865cf", null ]
    ] ],
    [ "GCAPSULEF", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#ab023c8b289687d73d60701d13de7d7b8", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a081a1cea097a8b02628f7000fecf7a41", null ],
      [ "start_x", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#af81d9036786fcd3f032b5f59119b616f", null ],
      [ "start_y", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a0366f714352731be1efc146080ae07bc", null ],
      [ "start_z", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a1e07be9a6918fe1a32d4fac81bad1c0a", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#ad3c52488a519f79dad5097851ae7bb89", null ],
      [ "end_x", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a12ba37fec97341a018ea6fa1537a30af", null ],
      [ "end_y", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a5cc80a1fb248f470c3f701dd9eb9443d", null ],
      [ "end_z", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#ae41cbe88380fbd34aa827b2a4f57d582", null ],
      [ "reserved", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a8e9f9810e45b3c8ca7a1636619bcb47d", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_f.html#a353d35a19dc1c5a46ea137c86d02fe41", null ]
    ] ],
    [ "GCAPSULED", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a05f9615fea294dfb9b227b4a32a27ebf", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#ae92d3c6d5ed1467a8d77569156bb4ded", null ],
      [ "start_x", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a2f1c3dfd9bd87a54bacda4dc15e03241", null ],
      [ "start_y", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#abfce48e69c7517a41d31e8fc6fa7ae21", null ],
      [ "start_z", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a17ed27cee3aa821787ab5432cc22ef90", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a78488b52fca815b60e493d2ca96111b4", null ],
      [ "end_x", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#aadf27c65016877beb4bbc209f636a2de", null ],
      [ "end_y", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a3a37e7a04f55ea667d762f85c0ee277b", null ],
      [ "end_z", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a9e32a1911382d3d6590587c502f1162e", null ],
      [ "reserved", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a5a6223a1e0d1f452436f33480018d167", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_c_a_p_s_u_l_e_d.html#a375afcb7e0c8c2c5cc80d88eb450c6a9", null ]
    ] ],
    [ "GAABBCEF", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html#a1324505f4ed1450f74b4dd52014cfd85", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html#adc0c7ab3416371972ac3c84f8738e793", null ],
      [ "center", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html#a210bbfdf80472b34f83a032b87f20335", null ],
      [ "extent", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html#a80c1dc868c405f6c0d845dff61c75681", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_f.html#a38ee6466227e52e0a6493671b468c452", null ]
    ] ],
    [ "GAABBCED", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html#a3f6223053e4e64e63eee256a7fb4804b", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html#a952cee8539192b152b3fadeb3a136567", null ],
      [ "center", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html#a5e9a4fedf462f993b31ac2deee79aac0", null ],
      [ "extent", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html#a215e4843e4eaf0b8cff570f3c05bc69d", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_c_e_d.html#a02ea1fddab672a4784b11b98261db0eb", null ]
    ] ],
    [ "GAABBMMF", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html#a3dead37fec6e3472be8b84e06ea82e96", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html#a29d299f7610f348a49778e8f07267831", null ],
      [ "min", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html#a6ff2d2f0ddfc46796d8f2c6bb1ff96d7", null ],
      [ "max", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html#a015ab8f7ba153eab001a6f1640b1c125", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_f.html#a4e88c75c8692ddb80eb3e2bcea888b14", null ]
    ] ],
    [ "GAABBMMD", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html#ab79a6af4f44bee002f31d86537613416", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html#ae1d1c40f933ae64ba8beea95941c9494", null ],
      [ "min", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html#aa1b0c6a90d92d3ce5d1aeb3a8cf7be96", null ],
      [ "max", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html#a6e5a9f5a370f5adbebee2e663ac2ab56", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_a_a_b_b_m_m_d.html#ade615dc1f4fe11325345021c82ae2c9a", null ]
    ] ],
    [ "GOBBF", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html#a38a705fa25da5e3dd684c09b07c357dc", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html#a55a012ece8ac1c3868cf5a0bc798e5a7", null ],
      [ "center", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html#a049f277cf0122fd1dae4cd5b08e215f4", null ],
      [ "extent", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html#afbb86430ad82520df31a6572967889d2", null ],
      [ "rotation", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html#af6441ba0c44472cb432ee7b835f58b66", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_f.html#a909377702d4f56d61144690847198f4b", null ]
    ] ],
    [ "GOBBD", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html", [
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html#ad28e4c796377a3ae454bfc34e385ab21", null ],
      [ "operator&", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html#a5485224863c494f2c4b17c40a7a8dc75", null ],
      [ "center", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html#a605cf1a4c0b36ecceef57168a1c24cc9", null ],
      [ "extent", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html#ab20ebf2a5c5dae34a1c6275ed5e07953", null ],
      [ "rotation", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html#aa5bd7568178ea59e50162b269edbfcf4", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h_1_1_g_o_b_b_d.html#a37394405de19fea938e08995e9b565be", null ]
    ] ],
    [ "GVECTOR2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_f.html", [
      [ "x", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_f.html#a6b6fef225643d4ddb49ab0b85055fb1d", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_f.html#a384642220477b2e7ced37d1581c2d0f6", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_f.html#ab413fa0fbaba20e94f8b60b4b7349131", null ]
    ] ],
    [ "GVECTOR2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_d.html", [
      [ "x", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_d.html#a9038dc5cd185469862096edb77306fcf", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_d.html#a1234164ec5385bd3792061a8fc9bb527", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r2_d.html#a878541c3725ceabb4391abae3ae50af6", null ]
    ] ],
    [ "GVECTOR3F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html", [
      [ "xy", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html#a6e50082eadcfdcffd5b0194fcdf7385c", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html#ade904c12afe624026a6a8b3c590c1009", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html#a9087746ef551a22086996ed55a8445a0", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html#a47e136c2f2d18fd4d792700b3c11d1f7", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_f.html#a80353413b0fc5938ce5df2dfa0605d63", null ]
    ] ],
    [ "GVECTOR3D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html", [
      [ "xy", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html#acaed5c542c7043cf4a26da58d42ca625", null ],
      [ "x", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html#a83c11d9f40fc7e12c47e642c4d7a5d06", null ],
      [ "y", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html#a34b12d8fa089a3f69a2573c278f0f55f", null ],
      [ "z", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html#a1b8e07c499ad0720e0a8b1e4c44350fb", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_v_e_c_t_o_r3_d.html#a37a1090cd2285dcd7ab0d3f1a65b2dab", null ]
    ] ],
    [ "GMATRIX2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_f.html", [
      [ "row1", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_f.html#a73264e44ebfbcda3865fb83ad48e2925", null ],
      [ "row2", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_f.html#a8cf1c3d0755897cd91abd8cdcb44319b", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_f.html#a498242a4b60c5bc07cf9489f63307eb0", null ]
    ] ],
    [ "GMATRIX2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_d.html", [
      [ "row1", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_d.html#a2d7f049f569a0db5a1f962e008d84146", null ],
      [ "row2", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_d.html#a105c250ff8fb5a3ff9eb0bc8e43e2733", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x2_d.html#a75182b7dcc7aa9f24a283378b674c90c", null ]
    ] ],
    [ "GMATRIX3F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_f.html", [
      [ "row1", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_f.html#ad774575da5d86fbf06cd04909bb6c47f", null ],
      [ "row2", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_f.html#a7c549cd470ce24985e442ab4edd6e847", null ],
      [ "row3", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_f.html#aa72425623ed3c5cbcd4076e7b3b30123", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_f.html#a924e11d91f8b02841adf438754459479", null ]
    ] ],
    [ "GMATRIX3D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_d.html", [
      [ "row1", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_d.html#a36c5a27f1866f87183f86e35c458c780", null ],
      [ "row2", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_d.html#a0abd73610f32de8b9737ea18fff4df03", null ],
      [ "row3", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_d.html#a182c8a922400f7d83c3e1e62ae407a8b", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_m_a_t_r_i_x3_d.html#aa0036b4ee737f648a9b0e68cd1b475ee", null ]
    ] ],
    [ "GLINE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_f.html", [
      [ "start", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_f.html#a0bb89be6ee22a13f7ba042d7fbe34228", null ],
      [ "end", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_f.html#a7e0ab9c1a4cd05652722ff522df42c85", null ]
    ] ],
    [ "GLINE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_d.html", [
      [ "start", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_d.html#aee3cd871e871c41f9ed80ce22a0a46d0", null ],
      [ "end", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_l_i_n_e2_d.html#a04cccffbc2b9286f619a92cfdc3f1e4a", null ]
    ] ],
    [ "GRAY2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_f.html", [
      [ "pos", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_f.html#aa4ec99630d96745a63e68c47ae2ba01c", null ],
      [ "dir", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_f.html#a5bb6f3d93e989d27d69dbdcc1b3f9477", null ]
    ] ],
    [ "GRAY2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_d.html", [
      [ "pos", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_d.html#afb6001417415da67065db22754e52bc2", null ],
      [ "dir", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_a_y2_d.html#a2b6c2bb16e9c728ab1b78aed5c18aa06", null ]
    ] ],
    [ "GCIRCLE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_f.html", [
      [ "pos", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_f.html#ae7b211a8abcdaf8c1c348ee206228d3f", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_f.html#a9300475a6d259547dd680673ea109de0", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_f.html#a1c78f2e27b1830d1f03e5e6dcad5f75e", null ]
    ] ],
    [ "GCIRCLE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_d.html", [
      [ "pos", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_d.html#a49e2fd07bc10f0d5cfc08a248cfe49e4", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_d.html#a91b34eb3b2800d93075ecc1061ba780f", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_i_r_c_l_e2_d.html#a2391edcfa7f9fab61c5e664d4cbcf3b8", null ]
    ] ],
    [ "GCAPSULE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_f.html", [
      [ "start", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_f.html#ad7017917f75c009a194322008a393125", null ],
      [ "end", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_f.html#ac2bcfcc327f6e5652744f62183d49479", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_f.html#af96416ea4c4cbdff6554508a86900bbd", null ]
    ] ],
    [ "GCAPSULE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_d.html", [
      [ "start", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_d.html#a9de945c086dd5f6ef51afae09e1a5ccc", null ],
      [ "end", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_d.html#a448b51c4d7c1bd7ec744549af2346e60", null ],
      [ "radius", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_c_a_p_s_u_l_e2_d.html#ae32ace3b6e86b936a3f729589d24bafb", null ]
    ] ],
    [ "GRECTANGLE2F", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_f.html", [
      [ "min", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_f.html#ac3a3f1f4f958ab149a69a5b45cf4f596", null ],
      [ "max", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_f.html#acf419ed8670ddf8bb40ed687a759b6cc", null ]
    ] ],
    [ "GRECTANGLE2D", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_d.html", [
      [ "min", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_d.html#abb3f76db1e9bf3a40f92bb69dbc5cea3", null ],
      [ "max", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_r_e_c_t_a_n_g_l_e2_d.html#a8190ece4b1bc84e84d0ee3147319831d", null ]
    ] ],
    [ "GBARYCENTRICF", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_f.html", [
      [ "alpha", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_f.html#a7a91ff46cc8cfb224ae8df90575924a8", null ],
      [ "beta", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_f.html#a2d6438b6d63f075f43655a7c12a1e2da", null ],
      [ "gamma", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_f.html#ad35d55d6823ace47957916c5d4504a96", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_f.html#a6602a6d254a97ab8055cfd88345bc8d2", null ]
    ] ],
    [ "GBARYCENTRICD", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_d.html", [
      [ "alpha", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_d.html#af523c4a6a37706b5d9ae09eaeb381dc8", null ],
      [ "beta", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_d.html#adbe5e78230b4f394b939b54f9a34e0ab", null ],
      [ "gamma", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_d.html#a2c97329555ccff9cfe6f44fe66586d8b", null ],
      [ "data", "struct_g_w_1_1_m_a_t_h2_d_1_1_g_b_a_r_y_c_e_n_t_r_i_c_d.html#a43e7b631ca1372a21a76fe2d8a094933", null ]
    ] ]
];