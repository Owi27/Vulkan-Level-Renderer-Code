var class_g_w_1_1_m_a_t_h2_d_1_1_g_vector2_d =
[
    [ "Create", "class_g_w_1_1_m_a_t_h2_d_1_1_g_vector2_d.html#a3ed33760c541258e9fec3711b0bdf1c3", null ]
];