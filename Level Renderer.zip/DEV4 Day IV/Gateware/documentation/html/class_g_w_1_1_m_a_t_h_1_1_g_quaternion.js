var class_g_w_1_1_m_a_t_h_1_1_g_quaternion =
[
    [ "Create", "class_g_w_1_1_m_a_t_h_1_1_g_quaternion.html#a750dd08b8966268134001159f3a3fa38", null ]
];