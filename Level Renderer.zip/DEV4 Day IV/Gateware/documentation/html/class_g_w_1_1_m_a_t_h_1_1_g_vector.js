var class_g_w_1_1_m_a_t_h_1_1_g_vector =
[
    [ "Create", "class_g_w_1_1_m_a_t_h_1_1_g_vector.html#a7c00fbdea79359a7b5e7de13ff39f556", null ]
];