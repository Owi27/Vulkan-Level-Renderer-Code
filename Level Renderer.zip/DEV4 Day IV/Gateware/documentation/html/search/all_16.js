var searchData=
[
  ['x_882',['x',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#aad10cee4c78ee9bcf33aa3d58182561a',1,'GW::GRAPHICS::GBlitter::TileDefinition::x()'],['../struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#ad1dcc3c890ed96608e893252b80f704d',1,'GW::INPUT::GBufferedInput::EVENT_DATA::x()']]]
];
