var searchData=
[
  ['data_1587',['data',['../struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#aa3def74bc6bf80ecddc5529ffcd48ffc',1,'GW::INPUT::GBufferedInput::EVENT_DATA']]],
  ['deviceextensioncount_1588',['deviceExtensionCount',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a0dedba2314e31a8f7641f29b757fcaf6',1,'GW::GRAPHICS::GVulkanSurface::GVulkanSurfaceQueryInfo']]],
  ['deviceextensionproperties_1589',['deviceExtensionProperties',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a96047d29f4e20102bdd058690c637c4c',1,'GW::GRAPHICS::GVulkanSurface::GVulkanSurfaceQueryInfo']]],
  ['deviceextensions_1590',['deviceExtensions',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html#a3f851bf3c1346029aac4d73e9b6cd83a',1,'GW::GRAPHICS::GVulkanSurface::GVulkanSurfaceQueryInfo']]],
  ['display_1591',['display',['../struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html#a4c21bc5627c779031ba3b4ba4a267734',1,'GW::SYSTEM::UNIVERSAL_WINDOW_HANDLE']]]
];
