var searchData=
[
  ['y_883',['y',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_tile_definition.html#a2deed3f43c2c92848d4418b1db54ef4b',1,'GW::GRAPHICS::GBlitter::TileDefinition::y()'],['../struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#a40c938fb94c8a0908bfac85f62f71fc9',1,'GW::INPUT::GBufferedInput::EVENT_DATA::y()']]]
];
