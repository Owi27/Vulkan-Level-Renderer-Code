var class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface =
[
    [ "Create", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html#ab76e2027ae0481331f16659fc0615562", null ],
    [ "GetAspectRatio", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html#ac69f4b13f6d6cbb0ce153b399ed2299b", null ],
    [ "GetContext", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html#a684ab643060c206bc65fc0579c3a7069", null ],
    [ "UniversalSwapBuffers", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html#a6a7fda7ba935e9fc22cd94ac47ebe886", null ],
    [ "QueryExtensionFunction", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html#a045548083dbdd547b18ef9b9a896f0de", null ],
    [ "EnableSwapControl", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html#a1a4d3e9f9e183a4987bf13187d802e66", null ]
];