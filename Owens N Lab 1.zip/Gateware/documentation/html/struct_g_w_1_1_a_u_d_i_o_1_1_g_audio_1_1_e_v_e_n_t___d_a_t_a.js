var struct_g_w_1_1_a_u_d_i_o_1_1_g_audio_1_1_e_v_e_n_t___d_a_t_a =
[
    [ "channelVolumes", "struct_g_w_1_1_a_u_d_i_o_1_1_g_audio_1_1_e_v_e_n_t___d_a_t_a.html#aaf22f556ea5fe3c501025545bfa50df8", null ],
    [ "numOfChannels", "struct_g_w_1_1_a_u_d_i_o_1_1_g_audio_1_1_e_v_e_n_t___d_a_t_a.html#a0a2cfb9389a84b9c7c25495a4517da3f", null ]
];