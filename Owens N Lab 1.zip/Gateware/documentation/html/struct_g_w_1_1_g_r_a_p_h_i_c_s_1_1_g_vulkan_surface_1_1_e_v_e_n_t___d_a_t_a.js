var struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a =
[
    [ "eventResult", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a.html#a13ba32e9a2df9e7a8587d32b2a2ef353", null ],
    [ "surfaceExtent", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a.html#af75bd6276601ff16ebe19ae1ee6ef24b", null ]
];