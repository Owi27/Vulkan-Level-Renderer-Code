var struct_g_w_1_1_g_event =
[
    [ "Write", "struct_g_w_1_1_g_event.html#a33493e7fa4b57b2e62d21f324ca7ec42", null ],
    [ "Read", "struct_g_w_1_1_g_event.html#a6b9042ee012bf81178a3e40708931991", null ],
    [ "Read", "struct_g_w_1_1_g_event.html#a443bf2cefed64acde11f1ec67d67a7bf", null ]
];