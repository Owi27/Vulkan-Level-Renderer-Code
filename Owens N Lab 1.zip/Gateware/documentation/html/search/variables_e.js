var searchData=
[
  ['screenx_1624',['screenX',['../struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#af3d4504c9b36f06a962b0aed6fa4d982',1,'GW::INPUT::GBufferedInput::EVENT_DATA']]],
  ['screeny_1625',['screenY',['../struct_g_w_1_1_i_n_p_u_t_1_1_g_buffered_input_1_1_e_v_e_n_t___d_a_t_a.html#adfbabf0902d029c5571115771fb379a6',1,'GW::INPUT::GBufferedInput::EVENT_DATA']]],
  ['stencil_1626',['stencil',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter_1_1_draw_instruction.html#a62ff9b40a11ce674e7592462dbc6fcf9',1,'GW::GRAPHICS::GBlitter::DrawInstruction']]],
  ['surfaceextent_1627',['surfaceExtent',['../struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a.html#af75bd6276601ff16ebe19ae1ee6ef24b',1,'GW::GRAPHICS::GVulkanSurface::EVENT_DATA']]]
];
