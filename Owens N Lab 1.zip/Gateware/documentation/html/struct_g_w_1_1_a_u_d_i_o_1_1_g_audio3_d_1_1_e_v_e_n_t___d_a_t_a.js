var struct_g_w_1_1_a_u_d_i_o_1_1_g_audio3_d_1_1_e_v_e_n_t___d_a_t_a =
[
    [ "position", "struct_g_w_1_1_a_u_d_i_o_1_1_g_audio3_d_1_1_e_v_e_n_t___d_a_t_a.html#a4b1e1075267dd10cb7d51fedc6f8eb38", null ],
    [ "quaternion", "struct_g_w_1_1_a_u_d_i_o_1_1_g_audio3_d_1_1_e_v_e_n_t___d_a_t_a.html#a1690611211488db5a231bfe5cfa19eec", null ]
];