var namespace_g_w =
[
    [ "AUDIO", "namespace_g_w_1_1_a_u_d_i_o.html", "namespace_g_w_1_1_a_u_d_i_o" ],
    [ "CORE", "namespace_g_w_1_1_c_o_r_e.html", "namespace_g_w_1_1_c_o_r_e" ],
    [ "GRAPHICS", "namespace_g_w_1_1_g_r_a_p_h_i_c_s.html", "namespace_g_w_1_1_g_r_a_p_h_i_c_s" ],
    [ "INPUT", "namespace_g_w_1_1_i_n_p_u_t.html", "namespace_g_w_1_1_i_n_p_u_t" ],
    [ "MATH", "namespace_g_w_1_1_m_a_t_h.html", "namespace_g_w_1_1_m_a_t_h" ],
    [ "MATH2D", "namespace_g_w_1_1_m_a_t_h2_d.html", "namespace_g_w_1_1_m_a_t_h2_d" ],
    [ "SYSTEM", "namespace_g_w_1_1_s_y_s_t_e_m.html", "namespace_g_w_1_1_s_y_s_t_e_m" ],
    [ "GEvent", "struct_g_w_1_1_g_event.html", "struct_g_w_1_1_g_event" ]
];