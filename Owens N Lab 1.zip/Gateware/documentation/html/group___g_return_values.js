var group___g_return_values =
[
    [ "GReturn", "group___g_return_values.html#gaf46a07bcad99edbe1e92a9fc99078617", [
      [ "FORMAT_UNSUPPORTED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617aad7e3cfdd56d166a8b33ddc7563b61aa", null ],
      [ "NO_IMPLEMENTATION", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a741d913c61ad067adf01a85e6807ad21", null ],
      [ "HARDWARE_UNAVAILABLE", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a0d614aea5f145517de4f929a5de0e0dd", null ],
      [ "DEADLOCK", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a8f35b656de87c54e18710fc94d73a614", null ],
      [ "UNEXPECTED_RESULT", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a87206a3a3609ea2ad8b2ee552bce14b0", null ],
      [ "RESOURCE_LOCKED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a587988706a4551493e5a0eb210b7e762", null ],
      [ "DISCONNECTED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a99c8ce56e7ab246445d3b134724428f3", null ],
      [ "PREMATURE_DEALLOCATION", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a3bf692e6ba8bddcabc1590f43bc08536", null ],
      [ "FUNCTION_DEPRECATED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a7b29591f7774d4d4dc0e0fe825dd32fc", null ],
      [ "FEATURE_UNSUPPORTED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617ab2a458b4cd30043189c97da3172fbc53", null ],
      [ "FILE_NOT_FOUND", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617acd54d99c8efb3c2db794197045f5b83c", null ],
      [ "INTERFACE_UNSUPPORTED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a16e5dd2df871109e9fee24a1e2fe900e", null ],
      [ "MEMORY_CORRUPTION", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a46798451fc1bd08482d7c01fc84109a6", null ],
      [ "INVALID_ARGUMENT", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617af295a0c3e37c94f078e1c5476479132d", null ],
      [ "IGNORED", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a92c30de24509d2778c9515bab375d253", null ],
      [ "EXPIRED_PROXY", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a905095d2c197a426ef8c4fbe89e87175", null ],
      [ "FAILURE", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a36fc6065a3e970bc3e6b2e59da52bf2a", null ],
      [ "EMPTY_PROXY", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617a83badd50cc7839e4bf5a26db49ca4fb4", null ],
      [ "SUCCESS", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617ad0749aaba8b833466dfcbb0428e4f89c", null ],
      [ "REDUNDANT", "group___g_return_values.html#ggaf46a07bcad99edbe1e92a9fc99078617ad6c0451a905c94474bcde8100cedb84c", null ]
    ] ]
];