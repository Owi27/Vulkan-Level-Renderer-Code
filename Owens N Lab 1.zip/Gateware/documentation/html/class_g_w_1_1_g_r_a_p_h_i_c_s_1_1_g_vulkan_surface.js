var class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface =
[
    [ "EVENT_DATA", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a.html", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_e_v_e_n_t___d_a_t_a" ],
    [ "GVulkanSurfaceQueryInfo", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info.html", "struct_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface_1_1_g_vulkan_surface_query_info" ],
    [ "Events", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a08023093707c5e54bc5b6ec56b8c65e8", [
      [ "REBUILD_PIPELINE", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a08023093707c5e54bc5b6ec56b8c65e8ae3be68bfbc65b0cfaa33ad7dc6d50d7d", null ],
      [ "RELEASE_RESOURCES", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a08023093707c5e54bc5b6ec56b8c65e8a6e21f495512b34ee70d3e2a9b03ed4b5", null ]
    ] ],
    [ "Create", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a7d8eaa13d7aafc8e2bf616059c153546", null ],
    [ "Create", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a1e12398ecc50dd3a32570500deba6843", null ],
    [ "GetAspectRatio", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#ab8ef2cdcd0a2d044a7406ed9c74dd7bb", null ],
    [ "GetSwapchainImageCount", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a31d8a1551ca1ec24205062fe46eb0528", null ],
    [ "GetSwapchainCurrentImage", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a90e2b3bd73b5162a60cb78e15562c921", null ],
    [ "GetQueueFamilyIndices", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a515f846b2beaf8558456d03ffafc5bb3", null ],
    [ "GetGraphicsQueue", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a74a7af6ea9355a6b200e2f039181a8f3", null ],
    [ "GetPresentQueue", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a430dea507e639b75ae53940f8c0be47a", null ],
    [ "GetSwapchainImage", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#adaf0752260969979f08f68f1bd0f5133", null ],
    [ "GetSwapchainView", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a767908c64ac0717121409a37f39af85b", null ],
    [ "GetSwapchainFramebuffer", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#ac51515fa4b5f303991c884823db4eecf", null ],
    [ "GetInstance", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a5bf31906c9dc7da5bea611e598b4efe2", null ],
    [ "GetSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a9314947fe5ae95dfdbbb8e0c60b670ba", null ],
    [ "GetPhysicalDevice", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#ab0a72275fe1d555587220964bd41d7e4", null ],
    [ "GetDevice", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a9fb2bb3a648eeac3afbc09ede88dacda", null ],
    [ "GetCommandPool", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a4fcae5fb671b48943e201cd7ec9930a9", null ],
    [ "GetSwapchain", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a138b205be45e8fd88df7b0e05fa1063a", null ],
    [ "GetRenderPass", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a2284e99e65b576800cdd26bede81637b", null ],
    [ "GetCommandBuffer", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a669ef38dfd1fa0cf6b754bffe55cb9e3", null ],
    [ "GetImageAvailableSemaphore", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a5d4527ce174dfb51bde1684757971b05", null ],
    [ "GetRenderFinishedSemaphore", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a905e00476b48df852a012cf1e45fb524", null ],
    [ "GetRenderFence", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a4c095e50f4a97a25ae452e9fcae695ad", null ],
    [ "StartFrame", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#a7594e6cf3cfc24e2197dc5b1e403bb02", null ],
    [ "EndFrame", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html#afbf8e8d3934bf0030c8a595fcf0aa4c0", null ]
];