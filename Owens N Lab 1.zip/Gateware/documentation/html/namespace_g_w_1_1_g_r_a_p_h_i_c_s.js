var namespace_g_w_1_1_g_r_a_p_h_i_c_s =
[
    [ "GBlitter", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_blitter" ],
    [ "GDirectX11Surface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x11_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x11_surface" ],
    [ "GDirectX12Surface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x12_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_direct_x12_surface" ],
    [ "GOpenGLSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_open_g_l_surface" ],
    [ "GRasterSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_raster_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_raster_surface" ],
    [ "GVulkanSurface", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface.html", "class_g_w_1_1_g_r_a_p_h_i_c_s_1_1_g_vulkan_surface" ]
];