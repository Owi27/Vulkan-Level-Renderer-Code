var namespace_g_w_1_1_s_y_s_t_e_m =
[
    [ "GConcurrent", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_concurrent.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_concurrent" ],
    [ "GDaemon", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_daemon" ],
    [ "GFile", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_file.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_file" ],
    [ "GLog", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_log" ],
    [ "GWindow", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window.html", "class_g_w_1_1_s_y_s_t_e_m_1_1_g_window" ],
    [ "UNIVERSAL_WINDOW_HANDLE", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e.html", "struct_g_w_1_1_s_y_s_t_e_m_1_1_u_n_i_v_e_r_s_a_l___w_i_n_d_o_w___h_a_n_d_l_e" ]
];